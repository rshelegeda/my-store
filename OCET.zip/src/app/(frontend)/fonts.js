import { Sofia_Sans } from "next/font/google";

export const sofiaSans = Sofia_Sans({
    weight: "900",
    subsets: ["latin", "cyrillic"],
    display: "swap",
});
